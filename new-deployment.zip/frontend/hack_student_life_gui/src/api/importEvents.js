import axios from "axios";
const fetchImportEvents = async () => {
    try {
        const response = await axios.get(`http://allevenstatuoft.us-east-1.elasticbeanstalk.com/api/import-events`);
        return response.data;
    } catch (error) {
        console.error("Error fetching events:", error);
        throw error;
    }
};

export default {
    fetchImportEvents
};